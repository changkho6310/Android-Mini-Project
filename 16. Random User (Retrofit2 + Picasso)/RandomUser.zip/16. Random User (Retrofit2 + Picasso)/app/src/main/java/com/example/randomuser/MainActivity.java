package com.example.randomuser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private TextView tvId;
    private TextView tvEmail;
    private TextView tvFirstName;
    private TextView tvLastName;
    private ImageView ivAvatar;
    private Button btnCallApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
    }

    private void addEvents() {

    }

    private void addControls() {
        tvId = findViewById(R.id.tvId);
        tvEmail = findViewById(R.id.tvEmail);
        tvFirstName = findViewById(R.id.tvFirstName);
        tvLastName = findViewById(R.id.tvLastName);
        ivAvatar = findViewById(R.id.ivAvatar);
        btnCallApi = findViewById(R.id.btnCallApi);
    }
}